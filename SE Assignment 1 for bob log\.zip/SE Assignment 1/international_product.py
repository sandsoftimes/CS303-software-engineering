from flask import Flask, jsonify

app = Flask(__name__)

# Array to store international brand products
international_products = [
    {"name": "Product X", "brand": "Brand A"},
    {"name": "Product Y", "brand": "Brand B"},
    {"name": "Product Z", "brand": "Brand C"}
]

@app.route('/international-products', methods=['GET'])
def get_international_products():
    return jsonify(international_products)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8001)
